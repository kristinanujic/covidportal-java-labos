package main.java.sample;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import main.java.sample.hr.covidportal.enums.VrijednostSimptoma;
import main.java.sample.hr.covidportal.main.Glavna_New;
import main.java.sample.hr.covidportal.model.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.*;

public class PretragaOsobeController implements Initializable {
    @FXML
    private TextField unosText;
    @FXML
    private TableView<Osoba> tableview=new TableView<>();
    @FXML
    private TableColumn<Osoba,String> ime=new TableColumn<>();
    @FXML
    private TableColumn<Osoba,String> prez=new TableColumn<>();
    @FXML
    private TableColumn<Osoba,String> preb=new TableColumn<>();
    @FXML
    private TableColumn<Osoba,String> bol=new TableColumn<>();
    @FXML
    private TableColumn<Osoba, List<Osoba>> kont=new TableColumn<>();

    public void citajOs() throws IOException, SQLException {
        String trazi=unosText.getText();
        List<String> list=Arrays.asList(trazi.split(" "));
        List<Osoba> osobe=BazaPodataka.getOsL();
        ObservableList<Osoba> filtrO=FXCollections.observableArrayList();
        for(Osoba z : osobe){
            if(list.size()>1) {
                if (z.getIme().toUpperCase().contains(list.get(0).toUpperCase()) || z.getPrezime().toUpperCase().contains(list.get(1).toUpperCase())) {
                    filtrO.add(z);
                }
            }
            else{
                if (z.getIme().toUpperCase().contains(list.get(0).toUpperCase()) || z.getPrezime().toUpperCase().contains(list.get(0).toUpperCase())) {
                    filtrO.add(z);
                }
            }
        }
        tableview.getItems().clear();
        tableview.getItems().addAll(filtrO);
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        ime.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getIme()));
        prez.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getPrezime()));
        preb.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getZupanija().getNaziv()));
        bol.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getZarazenBolescu().getNaziv()));
        kont.setCellValueFactory(cellData->new SimpleObjectProperty(cellData.getValue().getKontaktiraneOsobe().toString().substring(1,cellData.getValue().getKontaktiraneOsobe().toString().length() - 1)));
        tableview.setPlaceholder(new Label("No content."));
        try {
            tableview.getItems().addAll(BazaPodataka.getOsL());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }


    @FXML
    public void prikaziMeni() throws IOException {
        Parent glavni =
                FXMLLoader.load(getClass().getClassLoader().getResource("izbornik.fxml"));

        Scene glavniScene = new Scene(glavni, 600, 400);
        Main.getMainStage().setScene(glavniScene);
    }

    @FXML
    private void keyPressed(KeyEvent keyEvent) throws IOException, SQLException {
        if (keyEvent.getCode() == KeyCode.ENTER) {
            citajOs();
        }
    }
}
