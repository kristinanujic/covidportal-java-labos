package main.java.sample;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import main.java.sample.hr.covidportal.main.Glavna_New;
import main.java.sample.hr.covidportal.model.BazaPodataka;
import main.java.sample.hr.covidportal.model.Simptom;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.*;
import javafx.scene.input.KeyEvent;




public class PretragaSimptomiController implements Initializable {
    @FXML
    private TextField unosText;
    @FXML
    private TableView<Simptom> tableview=new TableView<>();
    @FXML
    private TableColumn<Simptom,String> naziv=new TableColumn<>();
    @FXML
    private TableColumn<Simptom, String> vrS=new TableColumn<>();


    /*public void citajSimp(){
        List<Simptom> simptom= Glavna_New.ucitavanjeSimp(1);
        String trazi=unosText.getText();
        ObservableList<Simptom> filtrS=FXCollections.observableArrayList();
        for(Simptom z : simptom){
            if(z.getNaziv().toUpperCase().contains(trazi.toUpperCase())){
                filtrS.add(z);
            }
        }
        tableview.getItems().clear();
        tableview.getItems().addAll(filtrS);
    }*/

    public void addsimp() throws IOException, SQLException {
        List<Simptom> simp=BazaPodataka.getSimpLDB();
        String trazi=unosText.getText();
        ObservableList<Simptom> filtrS= FXCollections.observableArrayList();
        for(Simptom z : simp){
            if(z.getNaziv().toUpperCase().contains(trazi.toUpperCase())){
                filtrS.add(z);
            }
        }
        tableview.getItems().clear();
        tableview.getItems().addAll(filtrS);
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        naziv.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getNaziv()));
        vrS.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getVrijednost().getVrijednost()));
        tableview.setPlaceholder(new Label("No content."));
        try {
            tableview.getItems().addAll(BazaPodataka.getSimpLDB());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @FXML
    public void prikaziMeni() throws IOException {
        Parent glavni =
                FXMLLoader.load(getClass().getClassLoader().getResource("izbornik.fxml"));

        Scene glavniScene = new Scene(glavni, 600, 400);
        Main.getMainStage().setScene(glavniScene);
    }

    @FXML
    private void keyPressed(KeyEvent keyEvent) throws IOException, SQLException {
        if (keyEvent.getCode() == KeyCode.ENTER) {
            addsimp();
        }

    }
}
