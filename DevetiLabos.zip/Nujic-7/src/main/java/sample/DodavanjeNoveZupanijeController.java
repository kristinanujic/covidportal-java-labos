package main.java.sample;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import main.java.sample.hr.covidportal.model.BazaPodataka;
import main.java.sample.hr.covidportal.model.Zupanija;

import java.io.IOException;
import java.sql.SQLException;


public class DodavanjeNoveZupanijeController{
    @FXML
    private TextField naziv;
    @FXML
    private TextField brStan;
    @FXML
    private TextField brZar;


    public void addZup() throws IOException, SQLException {
        Long id= Long.parseLong(String.valueOf(BazaPodataka.getSimpLDB().size()+1));
        String naziv1=naziv.getText();
        int brstan1= Integer.parseInt(brStan.getText());
        int brzar1=Integer.parseInt(brZar.getText());
        Zupanija zup=new Zupanija(naziv1,id,brstan1,brzar1);
        BazaPodataka.novaZup(zup);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Uspejsno dodano");
        alert.setHeaderText("Zupanija je uspjesno dodana");
        alert.showAndWait();

    }



    }

