package main.java.sample;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import main.java.sample.hr.covidportal.enums.VrijednostSimptoma;
import main.java.sample.hr.covidportal.main.Glavna_New;
import main.java.sample.hr.covidportal.model.BazaPodataka;
import main.java.sample.hr.covidportal.model.Simptom;
import main.java.sample.hr.covidportal.model.Bolest;
import main.java.sample.hr.covidportal.model.Zupanija;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.*;
import java.util.function.Predicate;


public class PetragaZupanijaController implements Initializable{
    @FXML
    private TextField unosText;
    @FXML
    private TableView<Zupanija> tableview=new TableView<>();
    @FXML
    private TableColumn<Zupanija,String> naziv=new TableColumn<>();
    @FXML
    private TableColumn<Zupanija,Integer> brSt=new TableColumn<>();
    @FXML
    private TableColumn<Zupanija,Integer> brZar=new TableColumn<>();



   /* public void citajZup(){
      List<Zupanija> zupanija= Glavna_New.ucitavanjeZup(1);
      String trazi=unosText.getText();
      ObservableList<Zupanija> filtrZup=FXCollections.observableArrayList();
      for(Zupanija z : zupanija){
          if(z.getNaziv().toUpperCase().contains(trazi.toUpperCase())){
              filtrZup.add(z);
          }
      }
        tableview.getItems().clear();
        tableview.getItems().addAll(filtrZup);
    }*/

    public void citajZup() throws IOException, SQLException {
        List<Zupanija> zupanija= BazaPodataka.getZupLDB();
        String trazi=unosText.getText();
        ObservableList<Zupanija> filtrZup=FXCollections.observableArrayList();
        for(Zupanija z : zupanija){
            if(z.getNaziv().toUpperCase().contains(trazi.toUpperCase())){
                filtrZup.add(z);
            }
        }
        tableview.getItems().clear();
        tableview.getItems().addAll(filtrZup);
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        naziv.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getNaziv()));
        brSt.setCellValueFactory(cellData->new SimpleIntegerProperty(cellData.getValue().getBrojStanovnika()).asObject());
        brZar.setCellValueFactory(cellData->new SimpleIntegerProperty(cellData.getValue().getBrZarazenih()).asObject());
        tableview.setPlaceholder(new Label("No content."));
        try {
            tableview.getItems().addAll(BazaPodataka.getZupLDB());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        tableview.setRowFactory(r->{
            TableRow<Zupanija> row=new TableRow<>();
            row.setOnMouseClicked(event->{
                if(event.getClickCount()==2&&(!row.isEmpty())){
                    Zupanija zup=row.getItem();
                    clicked(zup);
                }
            });
            return row;
        });
    }

    public void clicked(Zupanija zup){
        try{
            Parent dodbolFrame =
                    FXMLLoader.load(getClass().getClassLoader().getResource("dodavanjeNoveZupanije.fxml"));
            Scene dodbolScene = new Scene(dodbolFrame, 600, 400);
            Main.getMainStage().setScene(dodbolScene);
            FXMLLoader loader=new FXMLLoader(getClass().getClassLoader().getResource("dodavanjeNoveZupanije.fxml"));
            DodavanjeNoveZupanijeController controller=loader.getController();

        }catch(Exception e){
            e.printStackTrace();
        }
    }


    @FXML
    public void prikaziMeni() throws IOException {
        Parent glavni =
                FXMLLoader.load(getClass().getClassLoader().getResource("izbornik.fxml"));

        Scene glavniScene = new Scene(glavni, 600, 400);
        Main.getMainStage().setScene(glavniScene);
    }

    @FXML
    private void keyPressed(KeyEvent keyEvent) throws IOException, SQLException {
    if (keyEvent.getCode() == KeyCode.ENTER) {
        citajZup();
    }
}
}
