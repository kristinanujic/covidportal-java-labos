package main.java.sample;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import main.java.sample.hr.covidportal.main.Glavna_New;
import main.java.sample.hr.covidportal.model.*;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class DodavanjeNoveOsobeController implements Initializable {
    @FXML
    private TextField ime;
    @FXML
    private TextField prez;
    @FXML
    private TextField star;
    @FXML
    private ComboBox boxZup=new ComboBox();
    @FXML
    private ComboBox boxBol=new ComboBox();
    @FXML
    private ComboBox boxKont=new ComboBox();
    @FXML
    private List<Osoba> os=new ArrayList<>();

    public void dodKont(){
        Osoba simp= (Osoba) boxKont.getValue();
        os.add(simp);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Dodavanje uspjesno");
        alert.setHeaderText("Osoba je dodana");
        alert.showAndWait();
        boxKont.setPromptText("[Odabir]");
    }

    public void addOs() throws IOException, SQLException {
        String im = ime.getText().substring(0,1).toUpperCase()+ime.getText().substring(1).toLowerCase();
        String pr=prez.getText().substring(0,1).toUpperCase()+prez.getText().substring(1).toLowerCase();
        String st=star.getText();
        Zupanija zup=(Zupanija) boxZup.getValue();
        Long id=Long.parseLong(String.valueOf(BazaPodataka.getOsL().size()+1));
        Bolest bol=(Bolest) boxBol.getValue();
        Osoba osoba=new Osoba(id,im,pr,st,zup,bol,os);
        BazaPodataka.dodOs(osoba);
        ime.clear();
        prez.clear();
        star.clear();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        List<Osoba> kont=new ArrayList<>();
        try {
            kont.addAll(BazaPodataka.getOsL());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            boxZup.getItems().addAll(FXCollections.observableArrayList(BazaPodataka.getZupLDB()));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            boxBol.getItems().addAll(FXCollections.observableArrayList(BazaPodataka.getBolLDB()));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        boxKont.getItems().addAll(kont);
        boxZup.setPromptText("[Odabir]");
        boxBol.setPromptText("[Odabir]");
        boxKont.setPromptText("[Odabir]");
    }
    }

