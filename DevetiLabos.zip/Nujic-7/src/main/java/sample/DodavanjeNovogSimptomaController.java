package main.java.sample;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import main.java.sample.hr.covidportal.enums.VrijednostSimptoma;
import main.java.sample.hr.covidportal.model.BazaPodataka;
import main.java.sample.hr.covidportal.model.Simptom;


import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DodavanjeNovogSimptomaController implements Initializable {
    @FXML
    private TextField naziv;
    @FXML
    private RadioButton r1;
    @FXML
    private RadioButton r2;
    @FXML
    private RadioButton r3;
    @FXML
    private RadioButton r4;
    private ToggleGroup tg = new ToggleGroup();



    public void addSimp() throws IOException, SQLException {
        VrijednostSimptoma vr = null;
        if(r1.isSelected()){
            vr=VrijednostSimptoma.valueOf(r1.getText());
        }
        else if(r2.isSelected()){
            vr=VrijednostSimptoma.valueOf(r2.getText());
        }
        else if(r3.isSelected()){
            vr=VrijednostSimptoma.valueOf(r3.getText());
        }
        else if(r4.isSelected()){
            vr=VrijednostSimptoma.valueOf(r4.getText());
        }
        String naz = naziv.getText();
        Long id=Long.parseLong(String.valueOf(BazaPodataka.getSimpLDB().size()+1));
        Simptom simp=new Simptom(naz,id,vr);
        BazaPodataka.noviSimptom(simp);
        naziv.clear();
        tg.getSelectedToggle().setSelected(false);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Uspejsno dodano");
        alert.setHeaderText("Simptom je uspjesno dodan");
        alert.showAndWait();
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        r1.setToggleGroup(tg);
        r2.setToggleGroup(tg);
        r3.setToggleGroup(tg);
        r4.setToggleGroup(tg);
    }

    @FXML
    private void keyPressed(KeyEvent keyEvent) throws IOException, SQLException {
        if (keyEvent.getCode() == KeyCode.ENTER) {
            addSimp();
        }
    }
}
