package main.java.sample;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import main.java.sample.hr.covidportal.enums.VrijednostSimptoma;
import main.java.sample.hr.covidportal.main.Glavna_New;
import main.java.sample.hr.covidportal.model.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.*;
import javafx.scene.input.KeyEvent;

public class PretragaVirusaController implements Initializable{
    @FXML
    private TextField unosText;
    @FXML
    private TableView<Virus> tableview=new TableView<>();
    @FXML
    private TableColumn<Virus,String> naziv=new TableColumn<>();
    @FXML
    private TableColumn<Virus,List<Simptom>> nazivS=new TableColumn<>();




    public void citajVir() throws IOException, SQLException {
        List<Bolest> virusi= BazaPodataka.getBolLDB();
        List<Virus> bol=new ArrayList<>();
        for(Bolest b: virusi){
            if(b.getBol()){
                bol.add((Virus) b);
            }
        }
        String trazi=unosText.getText();
        ObservableList<Virus> filtrV=FXCollections.observableArrayList();
        for(Virus z : bol){
            if(z.getNaziv().toUpperCase().contains(trazi.toUpperCase())){
                filtrV.add(z);
            }
        }
        tableview.getItems().clear();
        tableview.getItems().addAll(filtrV);
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        naziv.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getNaziv()));
        nazivS.setCellValueFactory(cellData->new SimpleObjectProperty(cellData.getValue().getSimptomi().toString().substring(1,cellData.getValue().getSimptomi().toString().length() - 1)));
        tableview.setPlaceholder(new Label("No content."));
        List<Virus> bol=new ArrayList<>();
        try {
            for(Bolest b: BazaPodataka.getBolLDB()){
                if(b.getBol()){
                    bol.add((Virus) b);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        tableview.getItems().addAll(bol);

    }


    @FXML
    public void prikaziMeni() throws IOException {
        Parent glavni =
                FXMLLoader.load(getClass().getClassLoader().getResource("izbornik.fxml"));

        Scene glavniScene = new Scene(glavni, 600, 400);
        Main.getMainStage().setScene(glavniScene);
    }

    @FXML
    private void keyPressed(KeyEvent keyEvent) throws IOException, SQLException {
        if (keyEvent.getCode() == KeyCode.ENTER) {
            citajVir();
        }
    }
}

