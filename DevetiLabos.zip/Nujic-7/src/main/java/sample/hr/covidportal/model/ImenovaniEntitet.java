package main.java.sample.hr.covidportal.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Abstraktna klasa ImenovaniEntitet koju nasljeduju sve klase koje imaju atribut naziv
 */

public abstract class ImenovaniEntitet implements Serializable {
    String naziv;
    Long id;

    public ImenovaniEntitet(String naziv, Long id) {
        this.naziv = naziv;
        this.id = id;
    }

    public ImenovaniEntitet() {
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ImenovaniEntitet that = (ImenovaniEntitet) o;
        return Objects.equals(naziv, that.naziv) &&
                Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(naziv, id);
    }

    @Override
    public String toString() {
        return "ImenovaniEntitet{" +
                "naziv='" + naziv + '\'' +
                ", id=" + id +
                '}';
    }


}
