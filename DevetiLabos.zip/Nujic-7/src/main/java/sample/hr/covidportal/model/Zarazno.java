package main.java.sample.hr.covidportal.model;

/**
 * Sucelje koje ima metodu za prelazak zaraze na osobu s kojom je zarazena osoba bila u kontaktu
 */

public interface Zarazno {
    void prelazakZarazeNaOsobu(Osoba o);

}
