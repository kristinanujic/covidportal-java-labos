package main.java.sample.hr.covidportal.sort;
import main.java.sample.hr.covidportal.model.*;

import java.util.Comparator;

public class VirusSorter implements Comparator<Virus> {

    @Override
    public int compare(Virus v1, Virus v2) {
        String s1=v1.getNaziv();
        String s2=v2.getNaziv();
        return (s1.compareTo(s2))*(-1);
    }
}
