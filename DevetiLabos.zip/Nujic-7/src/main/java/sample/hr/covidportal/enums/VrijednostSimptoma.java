package main.java.sample.hr.covidportal.enums;

public enum VrijednostSimptoma {
    Produktivni("Produktivni"),
    Intenzivno("Intenzivno"),
    Visoka("Visoka"),
    Jaka("Jaka");

    private String vrijednost;

    VrijednostSimptoma(String vrijednost) {
        this.vrijednost = vrijednost;
    }

    VrijednostSimptoma() {
    }

    public String getVrijednost() {
        return vrijednost;
    }
}
