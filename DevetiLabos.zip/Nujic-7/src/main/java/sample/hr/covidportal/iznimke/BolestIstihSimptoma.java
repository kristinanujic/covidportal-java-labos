package main.java.sample.hr.covidportal.iznimke;

/**
 * Klasa koja sadrzi iznimku za bolesti/viruse istih simptoma
 */

public class BolestIstihSimptoma extends RuntimeException{
    public BolestIstihSimptoma() {
    }

    public BolestIstihSimptoma(String message) {
        super(message);
    }

    public BolestIstihSimptoma(String message, Throwable cause) {
        super(message, cause);
    }

    public BolestIstihSimptoma(Throwable cause) {
        super(cause);
    }
}
