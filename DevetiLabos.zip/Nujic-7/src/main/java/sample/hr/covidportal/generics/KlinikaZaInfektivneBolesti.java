package main.java.sample.hr.covidportal.generics;
import main.java.sample.hr.covidportal.model.*;

import java.util.*;

public class KlinikaZaInfektivneBolesti <T extends Virus,S extends Osoba> implements List<T> {
    List<T> virusi=new ArrayList<T>();
    List<S> zarazeneOsobe=new ArrayList<S>();

    public KlinikaZaInfektivneBolesti(List<T> virusi, List<S> zarazeneOsobe) {
        this.virusi = virusi;
        this.zarazeneOsobe = zarazeneOsobe;
    }

    public KlinikaZaInfektivneBolesti() {
    }

    public List<T> getVirusi() {
        return virusi;
    }

    public void setVirusi(List<T> virusi) {
        this.virusi = virusi;
    }

    public List<S> getZarazeneOsobe() {
        return zarazeneOsobe;
    }

    public void setZarazeneOsobe(List<S> zarazeneOsobe) {
        this.zarazeneOsobe = zarazeneOsobe;
    }

    public void addBolest(T Bolest){
        this.virusi.add(Bolest);
    }

    public void addOsoba(S Osoba){
        this.zarazeneOsobe.add(Osoba);
    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public boolean contains(Object o) {
        return false;
    }

    @Override
    public Iterator<T> iterator() {
        return null;
    }

    @Override
    public Object[] toArray() {
        return new Object[0];
    }

    @Override
    public <T1> T1[] toArray(T1[] a) {
        return null;
    }

    @Override
    public boolean add(T t) {
        return false;
    }

    @Override
    public boolean remove(Object o) {
        return false;
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return false;
    }

    @Override
    public boolean addAll(Collection<? extends T> c) {
        return false;
    }

    @Override
    public boolean addAll(int index, Collection<? extends T> c) {
        return false;
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        return false;
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        return false;
    }

    @Override
    public void clear() {

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        KlinikaZaInfektivneBolesti<?, ?> that = (KlinikaZaInfektivneBolesti<?, ?>) o;
        return Objects.equals(virusi, that.virusi) &&
                Objects.equals(zarazeneOsobe, that.zarazeneOsobe);
    }

    @Override
    public int hashCode() {
        return Objects.hash(virusi, zarazeneOsobe);
    }

    @Override
    public T get(int index) {
        return null;
    }

    @Override
    public T set(int index, T element) {
        return null;
    }

    @Override
    public void add(int index, T element) {

    }

    @Override
    public T remove(int index) {
        return null;
    }

    @Override
    public int indexOf(Object o) {
        return 0;
    }

    @Override
    public int lastIndexOf(Object o) {
        return 0;
    }

    @Override
    public ListIterator<T> listIterator() {
        return null;
    }

    @Override
    public ListIterator<T> listIterator(int index) {
        return null;
    }

    @Override
    public List<T> subList(int fromIndex, int toIndex) {
        return null;
    }

    @Override
    public String toString() {
        return "KlinikaZaInfektivneBolesti{" +
                "virusi=" + virusi +
                ", zarazeneOsobe=" + zarazeneOsobe +
                '}';
    }
}
