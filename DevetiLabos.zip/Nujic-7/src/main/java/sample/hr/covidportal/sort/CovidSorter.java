package main.java.sample.hr.covidportal.sort;
import main.java.sample.hr.covidportal.model.*;

import java.util.Comparator;

public class CovidSorter implements Comparator<Zupanija> {
    @Override
    public int compare(Zupanija zu1, Zupanija zu2) {
        double prosj1=((double)zu1.getBrZarazenih()/(double)zu1.getBrojStanovnika())*100;
        double prosj2=((double)zu2.getBrZarazenih()/(double)zu2.getBrojStanovnika())*100;
        if(prosj1<prosj2) {
            return 1;
        }
        else if(prosj1>prosj2) {
            return -1;
        }
        else{
            return 0;
        }
    }
}