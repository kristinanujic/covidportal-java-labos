package main.java.sample.hr.covidportal.model;
import java.io.Serializable;
import java.util.*;

/**
 * Klasa Bolest koja nasljeđuje abstraktnu klasu ImenovaniEntitet i ima atribute polje simptoma i naziv
 */

public class Bolest extends ImenovaniEntitet implements Serializable {
    List<Simptom> simptomi = new ArrayList<>();
    Boolean isBol;

    public Bolest() {
        /**
         * Konstruktor za klasu Bolest bez parametara
         */
    }

    public Bolest(String naziv, Long id, List<Simptom> simptomi,Boolean isBol) {
        super(naziv, id);
        this.simptomi = simptomi;
        this.isBol=isBol;
    }



    public List<Simptom> getSimptomi() {
        return simptomi;
    }

    public void setSimptomi(List<Simptom> simptomi) {
        this.simptomi = simptomi;
    }

    public Boolean getBol() {
        return isBol;
    }

    public void setBol(Boolean bol) {
        isBol = bol;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Bolest bolest = (Bolest) o;
        return Objects.equals(simptomi, bolest.simptomi);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), simptomi);
    }

    @Override
    public String toString() {
        return naziv;
    }
}





