package main.java.sample.hr.covidportal.generics;
import main.java.sample.hr.covidportal.model.*;
import java.util.*;

public class ZupGenerics <T extends Zupanija>{
    List<T> zup=new ArrayList<T>();

    public ZupGenerics(List<T> zup) {
        this.zup = zup;
    }

    public ZupGenerics() {
    }

    public List<T> getZup() {
        return zup;
    }

    public void setZup(List<T> zup) {
        this.zup = zup;
    }

    public void addZupanija(T Zupanija){
        this.zup.add(Zupanija);
    }

    public void Ispis(List<T> zupanija) {
        for (Zupanija zu : zupanija) {
            System.out.println("Naziv: " + zu.getNaziv() + "Broj Stanovnika: " + zu.getBrojStanovnika());
        }
    }

    @Override
    public String toString() {
        return "ZupanijaGenerics{" +
                "zup=" + zup +
                '}';
    }
}
