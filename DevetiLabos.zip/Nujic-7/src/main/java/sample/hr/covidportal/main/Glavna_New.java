package main.java.sample.hr.covidportal.main;
import javafx.scene.control.Alert;
import main.java.sample.hr.covidportal.model.*;
import main.java.sample.hr.covidportal.iznimke.*;
import main.java.sample.hr.covidportal.generics.*;
import main.java.sample.hr.covidportal.enums.*;
import main.java.sample.hr.covidportal.sort.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;
import java.util.stream.Collectors;

public class Glavna_New {
    /*public static final String SERIALIZATION_FILE_NAME= "dat/ser_zup.dat";


    public static void postoji(File dat){
        if(!dat.exists()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("ERROR");
                alert.setHeaderText("Datoteka "+dat+" nije pronadena!");
                alert.showAndWait();
                System.exit(1);
        }
    }

    public static void postojiDat(File dat){
        if(!dat.exists()) {
            System.out.println("Datoteka "+dat+" ne postoji!");
            System.exit(1);
        }
    }

    public static Long getSimpID(){
        List<Simptom> simp=ucitavanjeSimp(1);
        Simptom s=simp.get(simp.size()-1);
        return s.getId();
    }

    public static Long getZupID(){
        List<Zupanija> simp=ucitavanjeZup(1);
        Zupanija s=simp.get(simp.size()-1);
        return s.getId();
    }

    public static Long getVirID(){
        List<Virus> simp=readVir();
        Virus s=simp.get(simp.size()-1);
        return s.getId();
    }

    public static Long getBolID(){
        List<Bolest> simp=readBol();
        Bolest s=simp.get(simp.size()-1);
        return s.getId();
    }

    public static Long getOsID(){
        List<Osoba> simp=ucitavanjeOsobe(0);
        Osoba s=simp.get(simp.size()-1);
        return s.getId();
    }


    public static List<Zupanija> ucitavanjeZup(int i){
        File dat = new File("dat/zupanije.txt");
        if(i==0){
            postojiDat(dat);
        }
        else if(i==1){
            postoji(dat);
        }
        Long id;
        String naziv;
        int brStan=0;
        int brZar=0;
        String sifra;
        List<Zupanija> zupanija = new ArrayList<>();
        Scanner input;
        {
            try {
                input = new Scanner(dat);
                while (input.hasNextLine()) {
                    Zupanija zup = new Zupanija();
                    sifra=input.nextLine();
                    id=Long.parseLong(input.nextLine());
                    naziv=input.nextLine();
                    brStan=Integer.parseInt(input.nextLine());
                    brZar=Integer.parseInt(input.nextLine());
                    zup.setId(id);
                    zup.setNaziv(naziv);
                    zup.setBrojStanovnika(brStan);
                    zup.setBrZarazenih(brZar);
                    zupanija.add(zup);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return zupanija;
    }

    public static List<Simptom> ucitavanjeSimp(int i){
        File dat = new File("dat/simptomi.txt");
        if(i==0){
            postojiDat(dat);
        }
        else if(i==1){
            postoji(dat);
        }
        Long id;
        String naziv;
        String vrijednost;
        VrijednostSimptoma vs;
        List<Simptom> simptomi = new ArrayList<>();
        Scanner input;
        {
            try {
                input = new Scanner(dat);
                while (input.hasNextLine()) {
                    Simptom simp=new Simptom();
                    id=Long.parseLong(input.nextLine());
                    naziv=input.nextLine();
                    vrijednost=input.nextLine();
                    vs=VrijednostSimptoma.valueOf(vrijednost);
                    simp.setId(id);
                    simp.setNaziv(naziv);
                    simp.setVrijednost(vs);
                    simptomi.add(simp);

                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return simptomi;
    }

    public static List<Bolest> readBol(){
        File dat=new File("dat/bolesti.txt");
        if(!dat.exists()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Datoteka nije pronadena!");
            alert.showAndWait();
            System.exit(1);
        }
        Long id;
        String naziv;
        String pomStr;
        List<Bolest> bolesti=new ArrayList<>();
        List<Simptom> simptom=ucitavanjeSimp(1);
        Scanner input;
        {
            try {
                input = new Scanner(dat);
                while (input.hasNextLine()) {
                    List<String> listaSimptoma=new ArrayList<>();
                    Set<Simptom> simptomi=new HashSet<>();
                    Bolest bol=new Bolest();
                    id=Long.parseLong(input.nextLine());
                    naziv=input.nextLine();
                    pomStr=input.nextLine();
                    listaSimptoma= Arrays.asList(pomStr.split(","));
                    List<Long> listaLong=new ArrayList<>();
                    for(String s : listaSimptoma){
                        listaLong.add(Long.parseLong(s));
                    }
                    for(Long l : listaLong){
                        for(Simptom si : simptom) {
                            Simptom simp = new Simptom();
                            if (l==si.getId()) {
                                simp.setId(si.getId());
                                simp.setNaziv(si.getNaziv());
                                simp.setVrijednost(si.getVrijednost());
                                simptomi.add(simp);
                                break;
                            }
                        }
                    }
                    bol.setId(id);
                    bol.setNaziv(naziv);
                    bol.setSimptomi(simptomi);
                    bolesti.add(bol);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return bolesti;
    }

    public static List<Virus> readVir(){
        File dat=new File("dat/virusi.txt");
        if(!dat.exists()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Datoteka nije pronadena!");
            alert.showAndWait();
            System.exit(1);
        }
        Long id;
        String naziv;
        String pomStr;
        List<Virus> virusi=new ArrayList<>();
        List<Simptom> simptom=ucitavanjeSimp(1);
        Scanner input;
        {
            try {
                input = new Scanner(dat);
                while (input.hasNextLine()) {
                    List<String> listaSimptoma=new ArrayList<>();
                    Set<Simptom> simptomi=new HashSet<>();
                    Virus bol=new Virus();
                    id=Long.parseLong(input.nextLine());
                    naziv=input.nextLine();
                    pomStr=input.nextLine();
                    listaSimptoma= Arrays.asList(pomStr.split(","));
                    List<Long> listaLong=new ArrayList<>();
                    for(String s : listaSimptoma){
                        listaLong.add(Long.parseLong(s));
                    }
                    for(Long l : listaLong){
                        for(Simptom si : simptom) {
                            Simptom simp = new Simptom();
                            if (l==si.getId()) {
                                simp.setId(si.getId());
                                simp.setNaziv(si.getNaziv());
                                simp.setVrijednost(si.getVrijednost());
                                simptomi.add(simp);
                                break;
                            }
                        }
                    }
                    bol.setId(id);
                    bol.setNaziv(naziv);
                    bol.setSimptomi(simptomi);
                    virusi.add(bol);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return virusi;
    }


    public static List<Bolest> ucitavanjeBol(int i){
        File dat = new File("dat/bolesti.txt");
        File dat1 = new File("dat/virusi.txt");
        if(i==0){
            postojiDat(dat);
            postojiDat(dat1);
        }
        else if(i==1){
            postoji(dat);
            postoji(dat1);
        }
        Long id;
        String naziv;
        String pomStr;
        List<Bolest> bolesti=new ArrayList<>();
        List<Simptom> simptom=ucitavanjeSimp(i);
        Scanner input;
        {
            try {
                input = new Scanner(dat);
                while (input.hasNextLine()) {
                    List<String> listaSimptoma=new ArrayList<>();
                    Set<Simptom> simptomi=new HashSet<>();
                    Bolest bol=new Bolest();
                    id=Long.parseLong(input.nextLine());
                    naziv=input.nextLine();
                    pomStr=input.nextLine();
                    listaSimptoma= Arrays.asList(pomStr.split(","));
                    List<Long> listaLong=new ArrayList<>();
                    for(String s : listaSimptoma){
                        listaLong.add(Long.parseLong(s));
                    }
                    for(Long l : listaLong){
                        for(Simptom si : simptom) {
                            Simptom simp = new Simptom();
                            if (l==si.getId()) {
                                simp.setId(si.getId());
                                simp.setNaziv(si.getNaziv());
                                simp.setVrijednost(si.getVrijednost());
                                simptomi.add(simp);
                                break;
                            }
                        }
                    }
                    bol.setId(id);
                    bol.setNaziv(naziv);
                    bol.setSimptomi(simptomi);
                    bolesti.add(bol);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        {
            try {
                input = new Scanner(dat1);
                while (input.hasNextLine()) {
                    List<String> listaSimptoma=new ArrayList<>();
                    Set<Simptom> simptomi=new HashSet<>();
                    Virus bol=new Virus();
                    id=Long.parseLong(input.nextLine());
                    naziv=input.nextLine();
                    pomStr=input.nextLine();
                    listaSimptoma= Arrays.asList(pomStr.split(","));
                    List<Long> listaLong=new ArrayList<>();
                    for(String s : listaSimptoma){
                        listaLong.add(Long.parseLong(s));
                    }
                    for(Long l : listaLong){
                        for(Simptom si : simptom) {
                            Simptom simp = new Simptom();
                            if (l==si.getId()) {
                                simp.setId(si.getId());
                                simp.setNaziv(si.getNaziv());
                                simp.setVrijednost(si.getVrijednost());
                                simptomi.add(simp);
                                break;
                            }
                        }
                    }
                    bol.setId(id);
                    bol.setNaziv(naziv);
                    bol.setSimptomi(simptomi);
                    bolesti.add(bol);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return bolesti;
    }

    public static List<Osoba> ucitavanjeOsobe(int i){
        File dat = new File("dat/osobe.txt");
        if(i==0){
            postojiDat(dat);
        }
        else if(i==1){
            postoji(dat);
        }
        List<Zupanija> zup=ucitavanjeZup(i);
        List<Bolest> bol=ucitavanjeBol(i);
        Long id;
        String ime;
        String prez;
        int star;
        int zupa;
        int bole;
        String pomSt;
        List<Osoba> osobe = new ArrayList<>();
        Scanner input;
        {
            try {
                input = new Scanner(dat);
                while (input.hasNextLine()) {
                    Zupanija zupanija = new Zupanija();
                    List<Osoba> pomOs = new ArrayList<>();
                    id = Long.parseLong(input.nextLine());
                    ime = input.nextLine();
                    prez = input.nextLine();
                    star = Integer.parseInt(input.nextLine());
                    zupa = Integer.parseInt(input.nextLine());
                    bole = Integer.parseInt(input.nextLine());
                    pomSt = input.nextLine();
                    for(Zupanija z:zup){
                        if(zupa==z.getId()){
                            zupanija.setId(z.getId());
                            zupanija.setNaziv(z.getNaziv());
                            zupanija.setBrojStanovnika(z.getBrojStanovnika());
                            zupanija.setBrZarazenih(z.getBrZarazenih());
                            break;
                        }
                    }
                    List<String> listaOs= Arrays.asList(pomSt.split(","));
                    List<Long> listaLong=new ArrayList<>();
                    for(String s : listaOs){
                        listaLong.add(Long.parseLong(s));
                    }
                    for (Long l : listaLong) {
                        for (Osoba o : osobe) {
                            if (l == o.getId()) {
                                pomOs.add(o);
                            }
                        }
                    }

                    for (Bolest b : bol) {
                        if (b instanceof Virus) {
                            Virus bolest = new Virus();
                            if (bole == b.getId()) {
                                bolest.setId(b.getId());
                                bolest.setNaziv(b.getNaziv());
                                bolest.setSimptomi(b.getSimptomi());
                                Osoba os=new Osoba(ime,prez,star,zupanija,bolest,pomOs,id);
                                osobe.add(os);
                                break;
                            }
                        } else {
                            Bolest bolest = new Bolest();
                            if (bole == b.getId()) {
                                bolest.setId(b.getId());
                                bolest.setNaziv(b.getNaziv());
                                bolest.setSimptomi(b.getSimptomi());
                                Osoba os=new Osoba(ime,prez,star,zupanija,bolest,pomOs,id);
                                osobe.add(os);
                                break;
                            }
                        }
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return osobe;
    }

    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);


        List<Zupanija> zupanija = ucitavanjeZup(0);
        List<Simptom> simptom = ucitavanjeSimp(0);
        List<Bolest> bolest = ucitavanjeBol(0);
        List<Osoba> osoba = ucitavanjeOsobe(0);

        System.out.println("Ucitavanje podataka o zupanijama...");
        System.out.println("Ucitavanje podataka o simptomima...");
        System.out.println("Ucitavanje podataka o bolestima...");
        System.out.println("Ucitavanje podataka o virusima...");
        System.out.println("Ucitavanje osoba...");

        System.out.println("Popis osoba: ");
        for (Osoba o : osoba) {
            System.out.println(o);
            if (o.getKontaktiraneOsobe().size() == 0) {
                System.out.println("Nema kontaktiranih osoba.\n");
            } else {
                System.out.println("Kontaktirane osobe:");
                for (Osoba os : o.getKontaktiraneOsobe()) {
                    System.out.println(os.getIme() + " " + os.getPrezime());
                }
                System.out.println("\n");
            }
        }

        Map<Bolest, List<Osoba>> mapaBolesti = new HashMap<>();

        for (Osoba osoba1 : osoba) {
            List<Osoba> pom = new ArrayList<>();
            for (Osoba pomO : osoba) {
                if (osoba1.getZarazenBolescu().equals(pomO.getZarazenBolescu())) {
                    pom.add(pomO);
                }
                mapaBolesti.put(osoba1.getZarazenBolescu(), pom);
            }
        }

        int br = 0;
        for (Map.Entry<Bolest, List<Osoba>> entry : mapaBolesti.entrySet()) {
            System.out.print("\nOd bolesti " + entry.getKey().getNaziv() + " boluju: ");
            for (Osoba o : entry.getValue()) {
                System.out.print(o.getIme() + " " + o.getPrezime() + " ");
                if (br != (osoba.size() - 1)) {
                    System.out.print(", ");
                }
                br++;

            }
        }

        List<Osoba> pomOsoba = osoba.stream()
                .filter(x -> x.getZarazenBolescu() instanceof Virus)
                .map(x -> (Osoba) x)
                .collect(Collectors.toList());

        List<Virus> pomVir = bolest.stream()
                .filter(x -> x instanceof Virus)
                .map(x -> (Virus) x)
                .collect(Collectors.toList());

        KlinikaZaInfektivneBolesti<Virus, Osoba> infektivneBolesti = new KlinikaZaInfektivneBolesti(pomVir, pomOsoba);


        long startTime = System.currentTimeMillis();
        infektivneBolesti.getVirusi()
                .stream()
                .sorted(Comparator.comparing(Virus::getNaziv).reversed())
                .collect(Collectors.toList());
        long stopTime = System.currentTimeMillis();

        long startTime1 = System.currentTimeMillis();
        Collections.sort(infektivneBolesti.getVirusi(), new VirusSorter()); //????
        long stopTime1 = System.currentTimeMillis();
        System.out.println("Virusi sortirani silazno: ");
        for (int i = 0; i < infektivneBolesti.getVirusi().size(); i++) {
            System.out.println((i + 1) + ". " + infektivneBolesti.getVirusi().get(i).getNaziv());
        }

        System.out.println("\nSortiranje objekata korištenjem lambdi traje " + (stopTime - startTime) + " milisekundi, a bez lambda traje " + (stopTime1 - startTime1) + " milisekundi.");

        System.out.print("Unesite string za pretragu po prezimenu: ");
        String trazi = scan.nextLine();


        List<Osoba> nadeno = osoba.stream()
                .filter(x -> x.getPrezime().contains(trazi))
                .map(x -> (Osoba) x)
                .collect(Collectors.toList());

        Optional<Osoba> optOs = nadeno.stream()
                .findFirst();

        if (optOs.isEmpty()) {
            System.out.println("Nije pronadena niti jedna osoba.");
        } else {
            System.out.println("Osobe čije prezime sadrži “" + trazi + "” su sljedeće:");
            for (int i = 0; i < nadeno.size(); i++) {
                System.out.println((i + 1) + ". " + nadeno.get(i).getIme() + " " + nadeno.get(i).getPrezime());
            }
        }

        List<Integer> brojSimp = bolest.stream()
                .map(bol -> bol.getSimptomi().size())
                .collect(Collectors.toList());
        int i = 0;
        System.out.println("\n");
        for (Bolest bol : bolest) {
            System.out.println(bol.getNaziv() + " ima " + brojSimp.get(i) + " simptoma.");
            i++;
        }


        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(SERIALIZATION_FILE_NAME))) {
            for (Zupanija z : zupanija) {
                if (z.prosjek() >= 2) {
                    out.writeObject(z);
                }
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }


    }*/
}
