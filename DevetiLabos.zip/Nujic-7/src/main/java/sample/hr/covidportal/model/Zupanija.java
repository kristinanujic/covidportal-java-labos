package main.java.sample.hr.covidportal.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Klasa Zupanija koja nasljeduje abstraktnu klasu ImenovaniEntitet i ima atribute naziv i brojStanovnika
 */


public class Zupanija extends ImenovaniEntitet implements Serializable {
    int brojStanovnika;
    int brZarazenih;

    public Zupanija(String naziv, Long id, int brojStanovnika, int brZarazenih) {
        super(naziv, id);
        this.brojStanovnika = brojStanovnika;
        this.brZarazenih = brZarazenih;
    }

    public Zupanija(String naziv, Long id, int brojStanovnika) {
        super(naziv, id);
        this.brojStanovnika = brojStanovnika;
    }

    public Zupanija() {

    }

    public int getBrojStanovnika() {
        return brojStanovnika;
    }

    public void setBrojStanovnika(int brojStanovnika) {
        this.brojStanovnika = brojStanovnika;
    }

    public int getBrZarazenih() {
        return brZarazenih;
    }

    public void setBrZarazenih(int brZarazenih) {
        this.brZarazenih = brZarazenih;
    }


    public Double prosjek(){
        return (((double)this.getBrZarazenih()/(double)this.getBrojStanovnika())*100);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Zupanija zupanija = (Zupanija) o;
        return brojStanovnika == zupanija.brojStanovnika &&
                brZarazenih == zupanija.brZarazenih;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), brojStanovnika, brZarazenih);
    }

    @Override
    public String toString() {
        return naziv;
    }
}
