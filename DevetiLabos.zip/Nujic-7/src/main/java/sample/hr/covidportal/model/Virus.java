package main.java.sample.hr.covidportal.model;


import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Klasa Virus koja nasljeduje Klasu Bolest i implementira sucelje Zarazno
 */

public class Virus extends Bolest implements Zarazno, Serializable {

    public Virus(String naziv, Long id, List<Simptom> simptomi, Boolean isBol) {
        super(naziv, id, simptomi, isBol);
    }

    public Virus() {
        /**
         * Konstruktor za klasu Virus
         */
        super();
    }




    @Override
    public void prelazakZarazeNaOsobu(Osoba o) {
    }

    @Override
    public boolean equals(Object o) {
        return super.equals(o);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public String toString() {
        return naziv;
    }
}
