package main.java.sample.hr.covidportal.model;
import main.java.sample.hr.covidportal.enums.VrijednostSimptoma;


import java.io.Serializable;
import java.util.Objects;

/**
 * Klasa Simptom koja nasljeduje abstraktnu klasu ImenovaniEntitet i ima atribute naziv i vrijednost simptoma
 */



public class Simptom extends ImenovaniEntitet implements Serializable {
    VrijednostSimptoma vrijednost;

    public Simptom(String naziv, Long id, VrijednostSimptoma vrijednost) {
        super(naziv, id);
        this.vrijednost = vrijednost;
    }

    public Simptom() {
        /**
         * Konstruktor za klasu Simptom bez parametara
         */

        super();

    }

    public VrijednostSimptoma getVrijednost() {
        return vrijednost;
    }

    public void setVrijednost(VrijednostSimptoma vrijednost) {
        this.vrijednost = vrijednost;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Simptom simptom = (Simptom) o;
        return vrijednost == simptom.vrijednost;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), vrijednost);
    }

    @Override
    public String toString() {
        return naziv;
    }
}

