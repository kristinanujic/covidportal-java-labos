package main.java.sample.hr.covidportal.iznimke;

/**
 * Klasa koja sadrzi iznimku za duplikate kontaktiranih osoba
 */

public class DuplikatKontaktiraneOsobe extends Exception {
    public DuplikatKontaktiraneOsobe() {
    }

    public DuplikatKontaktiraneOsobe(String message) {
        super(message);
    }

    public DuplikatKontaktiraneOsobe(String message, Throwable cause) {
        super(message, cause);
    }

    public DuplikatKontaktiraneOsobe(Throwable cause) {
        super(cause);
    }
}
