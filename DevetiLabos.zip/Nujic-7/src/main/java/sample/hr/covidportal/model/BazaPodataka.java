package main.java.sample.hr.covidportal.model;

import main.java.sample.hr.covidportal.enums.VrijednostSimptoma;

import javax.swing.plaf.nimbus.State;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class BazaPodataka {
    private static Connection connectToDB() throws IOException, SQLException {
     Properties svojstva = new Properties();

        svojstva.load(new FileReader("src\\main\\resources\\database.properties"));

        String urlBazePodataka = svojstva.getProperty("db.url");
        String korisnicoIme = svojstva.getProperty("db.user");
        String lozinka = svojstva.getProperty("db.password");

        Connection veza = DriverManager.getConnection(urlBazePodataka, korisnicoIme, lozinka);

      
        return veza;
    }

    private static void closeDB(Connection veza) throws SQLException {
        veza.close();
    }

    public static List<Simptom> getSimpLDB() throws SQLException, IOException {
        Connection veza=connectToDB();
        String query = "SELECT * FROM SIMPTOM";
        Statement st = veza.createStatement();
        List<Simptom> simpL=new ArrayList<>();
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Simptom simp = new Simptom();
            long id = rs.getLong("ID");
            String naziv = rs.getString("NAZIV");
            String vrijednost = rs.getString("VRIJEDNOST");
            simp.setId(id);
            simp.setVrijednost(VrijednostSimptoma.valueOf(vrijednost));
            simp.setNaziv(naziv);
            simpL.add(simp);
        }
        closeDB(veza);
        return simpL;
    }

    public static Simptom getSimpDB(long id) throws SQLException, IOException {
        Connection veza=connectToDB();
        String query = "SELECT * FROM SIMPTOM WHERE ID ="+id;
        Statement st = veza.createStatement();
        ResultSet rs = st.executeQuery(query);
        Simptom simp=new Simptom();
        while(rs.next()) {
            long id1 = rs.getLong("ID");
            String naziv = rs.getString("NAZIV");
            String vrijednost = rs.getString("VRIJEDNOST");
           simp.setNaziv(naziv);
           simp.setId(id1);
           simp.setVrijednost(VrijednostSimptoma.valueOf(vrijednost));
        }
        closeDB(veza);
        return simp;
    }

    public static void noviSimptom(Simptom simp) throws SQLException, IOException {
        Connection veza=connectToDB();
        PreparedStatement upit=veza.prepareStatement("INSERT INTO SIMPTOM(id,naziv,vrijednost) VALUES(?,?,?)");
        upit.setLong(1,simp.getId());
        upit.setString(2,simp.getNaziv());
        upit.setString(3,simp.getVrijednost().getVrijednost());
        upit.executeUpdate();
        closeDB(veza);
    }

    public static List<Zupanija> getZupLDB() throws IOException, SQLException {
        Connection veza=connectToDB();
        String query = "SELECT * FROM ZUPANIJA";
        Statement st = veza.createStatement();
        List<Zupanija> zupl=new ArrayList<>();
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Zupanija zup = new Zupanija();
            long id = rs.getLong("ID");
            String naziv=rs.getString("NAZIV");
            int brstan = rs.getInt("BROJ_STANOVNIKA");
            int brojzar = rs.getInt("BROJ_ZARAZENIH_STANOVNIKA");
            zup.setId(id);
            zup.setNaziv(naziv);
            zup.setBrojStanovnika(brstan);
            zup.setBrZarazenih(brojzar);
            zupl.add(zup);
        }
        closeDB(veza);
        return zupl;
    }

    public static Zupanija getZupDB(long id) throws SQLException, IOException {
        Connection veza=connectToDB();
        String query = "SELECT * FROM ZUPANIJA WHERE ID ="+String.valueOf(id);
        Statement st = veza.createStatement();
        ResultSet rs = st.executeQuery(query);
        Zupanija zup=new Zupanija();
        while(rs.next()) {
            long id1 = rs.getLong("ID");
            String naziv = rs.getString("NAZIV");
            int brstan = rs.getInt("BROJ_STANOVNIKA");
            int brojzar = rs.getInt("BROJ_ZARAZENIH_STANOVNIKA");
            zup.setNaziv(naziv);
            zup.setId(id1);
            zup.setBrZarazenih(brojzar);
            zup.setBrojStanovnika(brstan);
        }
        closeDB(veza);
        return zup;
    }

    public static void novaZup(Zupanija zup) throws SQLException, IOException {
        Connection veza=connectToDB();
        PreparedStatement upit=veza.prepareStatement("INSERT INTO ZUPANIJA(id,naziv,BROJ_STANOVNIKA,BROJ_ZARAZENIH_STANOVNIKA) VALUES(?,?,?,?)");
        upit.setLong(1,zup.getId());
        upit.setString(2,zup.getNaziv());
        upit.setInt(3,zup.getBrojStanovnika());
        upit.setInt(4,zup.getBrZarazenih());
        upit.executeUpdate();
        closeDB(veza);
    }

    public static List<Simptom> getBolSimp(Long id) throws SQLException, IOException {
        Connection veza=connectToDB();
        String query = "SELECT * FROM BOLEST_SIMPTOM";
        Statement st = veza.createStatement();
        ResultSet rs = st.executeQuery(query);
        List<Simptom> svisimp=getSimpLDB();
        List<Simptom> res=new ArrayList<>();
        while(rs.next()){
            Long id1=rs.getLong("bolest_id");
            Long simpID=rs.getLong("SIMPTOM_ID");
            if(id==id1){
                for(Simptom s:svisimp){
                    if(s.getId()==simpID){
                        res.add(s);
                    }
                }
            }
        }
        return res;
    }

    public static List<Bolest> getBolLDB() throws IOException, SQLException {
        Connection veza=connectToDB();
        String query = "SELECT * FROM BOLEST";
        Statement st = veza.createStatement();
        List<Bolest> boll=new ArrayList<>();
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
           Long id=rs.getLong("ID");
           String naziv=rs.getString("NAZIV");
           Boolean bool=rs.getBoolean("VIRUS");
           List<Simptom> s=getBolSimp(id);
           if(bool){
               Virus vir=new Virus(naziv,id,s,bool);
               boll.add(vir);
           }
           else{
               Bolest vir=new Bolest(naziv,id,s,bool);
               boll.add(vir);
           }
        }
        closeDB(veza);
        return boll;
    }

    public static Bolest getBolDb(Long id) throws IOException, SQLException {
        Connection veza=connectToDB();
        String query = "SELECT * FROM BOLEST WHERE ID ="+String.valueOf(id);
        Statement st = veza.createStatement();
        ResultSet rs = st.executeQuery(query);
        Bolest bol=new Bolest();
        while(rs.next()) {
            Long id1=rs.getLong("id");
            String naziv=rs.getString("naziv");
            Boolean bool=rs.getBoolean("VIRUS");
            List<Simptom> s=getBolSimp(id);
            bol.setId(id1);
            bol.setNaziv(naziv);
            bol.setBol(bool);
            bol.setSimptomi(s);
        }
        return bol;
    }

    public static void dodBol(Bolest bol) throws IOException, SQLException {
        Connection veza=connectToDB();
        PreparedStatement upit=veza.prepareStatement("INSERT INTO BOLEST(id,naziv,virus) VALUES(?,?,?)");
        upit.setLong(1,bol.getId());
        upit.setString(2,bol.getNaziv());
        upit.setBoolean(3,bol.getBol());
        upit.executeUpdate();
        for(int i=0;i<bol.getSimptomi().size();i++) {
            PreparedStatement upit1 = veza.prepareStatement("INSERT INTO BOLEST_SIMPTOM(bolest_id,simptom_id) VALUES(?,?)");
            upit1.setLong(1, bol.getId());
            upit1.setLong(2, bol.getSimptomi().get(i).getId());
            upit1.executeUpdate();
        }
        closeDB(veza);
    }


    public static List<Osoba> getKont(Long id,List<Osoba> osobe) throws IOException, SQLException {
        Connection veza=connectToDB();
        String query = "SELECT * FROM KONTAKTIRANE_OSOBE";
        Statement st = veza.createStatement();
        ResultSet rs = st.executeQuery(query);
        List<Osoba> res=new ArrayList<>();
        while(rs.next()){
            Long id1=rs.getLong("osoba_id");
            Long osID=rs.getLong("kontaktirana_osoba_id");
            if(id1==id){
                for(Osoba o:osobe){
                    if(o.getId()==osID){
                        res.add(o);
                    }
                }
            }
        }
        return res;
    }

    public static Osoba getOs(Long id,List<Osoba> osobe) throws IOException, SQLException {
        Connection veza=connectToDB();
        String query = "SELECT * FROM KONTAKTIRANE_OSOBE HWERE ID="+id;
        Statement st = veza.createStatement();
        ResultSet rs = st.executeQuery(query);
        Osoba os=new Osoba();
        while (rs.next()) {
            Long id1 = rs.getLong("ID");
            String ime = rs.getString("ime");
            String prez = rs.getString("prezime");
            String datr = rs.getString("datum_rodjenja");
            Long zupID = rs.getLong("zupanija_id");
            Long bolid = rs.getLong("bolest_id");
            os.setId(id);
            os.setIme(ime);
            os.setPrezime(prez);
            os.setDatRod(datr);
            os.setZupanija(getZupDB(zupID));
            os.setZarazenBolescu(getBolDb(bolid));
            List<Osoba> kont = getKont(os.getId(), osobe);
            os.setKontaktiraneOsobe(kont);
        }
        closeDB(veza);
        return os;
    }

    public static List<Osoba> getOsL() throws IOException, SQLException {
        Connection veza=connectToDB();
        String query = "SELECT * FROM OSOBA";
        Statement st = veza.createStatement();
        List<Osoba> oso=new ArrayList<>();
        List<Zupanija> zup=getZupLDB();
        List<Bolest> bol=getBolLDB();
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Osoba os=new Osoba();
            Long id=rs.getLong("ID");
            String ime=rs.getString("ime");
            String prez=rs.getString("prezime");
            String datr=rs.getString("datum_rodjenja");
            Long zupID=rs.getLong("zupanija_id");
            Long bolid=rs.getLong("bolest_id");
            /*for(Zupanija z:zup){
                if(z.getId()==zupID){
                    os.setZupanija(z);
                }
            }*/
            os.setZupanija(getZupDB(zupID));
            /*for(Bolest b:bol){
                if(b.getId()==bolid){
                    os.setZarazenBolescu(b);
                }
            }*/
            os.setZarazenBolescu(getBolDb(bolid));
            os.setId(id);
            os.setIme(ime);
            os.setPrezime(prez);
            os.setDatRod(datr);
            oso.add(os);
        }
        for(int i=0;i<oso.size();i++){
            List<Osoba> kont=getKont(oso.get(i).getId(),oso);
            oso.get(i).setKontaktiraneOsobe(kont);
        }
        closeDB(veza);
        return oso;
    }

    public static void dodOs(Osoba osoba) throws IOException, SQLException {
        Connection veza=connectToDB();
        PreparedStatement upit=veza.prepareStatement("INSERT INTO OSOBA(id,ime,prezime,datum_rodjenja,zupanija_id,bolest_id) VALUES(?,?,?,?,?,?)");
        upit.setLong(1,osoba.getId());
        upit.setString(2,osoba.getIme());
        upit.setString(3,osoba.getPrezime());
        upit.setString(4,osoba.getDatRod());
        upit.setLong(5,osoba.getZupanija().getId());
        upit.setLong(6,osoba.getZarazenBolescu().getId());
        upit.executeUpdate();
        for(int i=0;i<osoba.getKontaktiraneOsobe().size();i++) {
            if(osoba.getKontaktiraneOsobe().get(i)!=null) {
                PreparedStatement upit1 = veza.prepareStatement("INSERT INTO KONTAKTIRANE_OSOBE(osoba_id,kontaktirana_osoba_id) VALUES(?,?)");
                upit1.setLong(1, osoba.getId());
                upit1.setLong(2, osoba.getKontaktiraneOsobe().get(i).getId());
                upit1.executeUpdate();
            }
        }
        closeDB(veza);
    }







}
