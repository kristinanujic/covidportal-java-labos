package main.java.sample.hr.covidportal.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * predstavlja entitet osoba koji je definiran imenom,prezimenom,staroscu,zupanijom,bolescu i kontaktiranim osobama
 *
 * @author Kristina
 */


public class Osoba implements Serializable {
    String ime;
    String prezime;
    String datRod;
    Zupanija zupanija;
    Bolest zarazenBolescu;
    List<Osoba> kontaktiraneOsobe = new ArrayList<>();
    Long id;




    /**
     * Builder za klasu Osoba
     */



    public Osoba() {
        /**
         * Konstruktor za klasu Osoba bez parametara
         */
    }


    public Osoba(Long id,String ime, String prezime, String datRod, Zupanija zupanija, Bolest zarazenBolescu, List<Osoba> kontaktiraneOsobe) {
        this.ime = ime;
        this.prezime = prezime;
        this.datRod= datRod;
        this.zupanija = zupanija;
        this.zarazenBolescu = zarazenBolescu;
        this.kontaktiraneOsobe = kontaktiraneOsobe;
            if (zarazenBolescu.getBol() == true) {
                for (Osoba kont : kontaktiraneOsobe) {
                    if (kont != null) {
                        kont.zarazenBolescu.setBol(zarazenBolescu.getBol());
                        kont.zarazenBolescu.setId(zarazenBolescu.getId());
                        kont.zarazenBolescu.setNaziv(zarazenBolescu.getNaziv());
                        kont.zarazenBolescu.setSimptomi(zarazenBolescu.getSimptomi());
                    }
                }
            }
        this.id=id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }


    public Zupanija getZupanija() {
        return zupanija;
    }

    public void setZupanija(Zupanija zupanija) {
        this.zupanija = zupanija;
    }

    public Bolest getZarazenBolescu() {
        return zarazenBolescu;
    }

    public void setZarazenBolescu(Bolest zarazenBolescu) {
        this.zarazenBolescu = zarazenBolescu;
    }

    public List<Osoba> getKontaktiraneOsobe() {
        return kontaktiraneOsobe;
    }

    public void setKontaktiraneOsobe(List<Osoba> kontaktiraneOsobe) {
        this.kontaktiraneOsobe = kontaktiraneOsobe;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Osoba osoba = (Osoba) o;
        return datRod== osoba.datRod &&
                Objects.equals(ime, osoba.ime) &&
                Objects.equals(prezime, osoba.prezime) &&
                Objects.equals(zupanija, osoba.zupanija) &&
                Objects.equals(zarazenBolescu, osoba.zarazenBolescu) &&
                Objects.equals(kontaktiraneOsobe, osoba.kontaktiraneOsobe) &&
                Objects.equals(id, osoba.id);
    }

    public String getDatRod() {
        return datRod;
    }

    public static Integer getAge(Osoba os){
        String datrod1=os.getDatRod();
        String[] y1=datrod1.split("-");
        String year=y1[0];
        String month=y1[1];
        String day=y1[2];
        LocalDate birthDate = LocalDate.of(Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day));
        String cury= LocalDate.now().toString();
        String[] y3=cury.split("-");
        String curyear=y3[0];
        String curm=y3[1];
        String curd=y3[2];
        LocalDate currdate=LocalDate.of(Integer.parseInt(curyear),Integer.parseInt(curm),Integer.parseInt(curd));
        return Period.between(birthDate, currdate).getYears();

    }

    public void setDatRod(String datRod) {
        this.datRod = datRod;
    }


    @Override
    public String toString() {
        return  ime + " "+ prezime;
    }
}
