package main.java.sample;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import main.java.sample.hr.covidportal.main.Glavna_New;

import javafx.scene.control.TextField;
import main.java.sample.hr.covidportal.model.BazaPodataka;
import main.java.sample.hr.covidportal.model.Bolest;
import main.java.sample.hr.covidportal.model.Simptom;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class DodavanjeNoveBolestiController implements Initializable {
    @FXML
    private TextField naziv;
    @FXML
    private ComboBox box=new ComboBox();
    @FXML
    private List<Simptom> simptomi=new ArrayList<>();

    public void dodSimp(){
        Simptom simp= (Simptom) box.getValue();
        simptomi.add(simp);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Dodavanje uspjesno");
        alert.setHeaderText("Simptom je dodan");
        alert.showAndWait();
        box.setPromptText("[Odabir]");
    }

    public void addBol() throws IOException, SQLException {
        String naz = naziv.getText();
        Long id= Long.parseLong(String.valueOf(BazaPodataka.getBolLDB().size()+1));
        Bolest bol=new Bolest(naz,id,simptomi,false);
        BazaPodataka.dodBol(bol);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Uspejsno dodano");
        alert.setHeaderText("Bolest je dodana uspjesno");
        alert.showAndWait();
        naziv.clear();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            box.getItems().addAll(FXCollections.observableArrayList(BazaPodataka.getSimpLDB()));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        box.setPromptText("[Odabir]");
    }

    @FXML
    private void keyPressedSimp(KeyEvent keyEvent) {
        if (keyEvent.getCode() == KeyCode.ENTER) {
            dodSimp();
        }
    }
    @FXML
    private void keyPressedBol(KeyEvent keyEvent) throws IOException, SQLException {
        if (keyEvent.getCode() == KeyCode.ENTER) {
            addBol();
        }
    }

}
